export default defineNuxtConfig({
  extends: ['docus'],
  modules: ['nuxt-studio'],
  css: ['~/assets/css/main.css'],
  ui: {
    page: {
      slots: {
        root: 'flex flex-col lg:grid lg:grid-cols-12 lg:gap-10',
        left: 'lg:col-span-2',
        center: 'lg:col-span-9',
        right: 'lg:col-span-3 order-first lg:order-last'
      },
      compoundVariants: [
        {
          left: true,
          right: true,
          class: {
            center: 'lg:col-span-7'
          }
        },
        {
          left: false,
          right: false,
          class: {
            center: 'lg:col-span-12'
          }
        }
      ]
    }
  }
})

